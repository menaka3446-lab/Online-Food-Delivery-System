package com.menakasoft.foodiex.features.home;

public class HomeView {
}
