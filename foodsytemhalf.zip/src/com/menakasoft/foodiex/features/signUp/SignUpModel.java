package com.menakasoft.foodiex.features.signUp;

public class SignUpModel {

}
