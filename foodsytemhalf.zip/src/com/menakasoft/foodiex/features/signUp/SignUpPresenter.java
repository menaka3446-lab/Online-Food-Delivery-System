package com.menakasoft.foodiex.features.signUp;

public class SignUpPresenter {
    public SignUpPresenter(SignUpView signUpView) {
    }
}
