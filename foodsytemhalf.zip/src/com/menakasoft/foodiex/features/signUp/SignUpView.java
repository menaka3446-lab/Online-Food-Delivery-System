package com.menakasoft.foodiex.features.signUp;

import java.util.Scanner;

interface SignUpInter {
    String getUsername();

    String getEmail();

    String getPassword();

    void showSuccess(String message);

    void showError(String message);
}


public class SignUpView implements SignUpInter {

    private Scanner scanner=new Scanner(System.in);
    private SignUpPresenter presenter;

    public SignUpView(){
        presenter=new SignUpPresenter(this);
    }
    public void init(){
        presenter.signup();
    }
    @Override
    public String getUsername() {
        System.out.println("Enter Username");
        return scanner.nextLine();
    }

    @Override
    public String getEmail() {
        System.out.println("Enter Email");
        return scanner.nextLine();
    }

    @Override
    public String getPassword() {
        System.out.println("Enter Password");
        return scanner.nextLine();
    }

    @Override
    public void showSuccess(String message) {
        System.out.println("SUCCESS: "+message);

    }

    @Override
    public void showError(String message) {
        System.out.println("Error: "+message);

    }
}
