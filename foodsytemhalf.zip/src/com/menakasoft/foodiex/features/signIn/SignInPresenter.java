package com.menakasoft.foodiex.features.signIn;

public class SignInPresenter {
}
