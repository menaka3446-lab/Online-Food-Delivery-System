package com.menakasoft.foodiex.util;

public class ParseHelper {
}
